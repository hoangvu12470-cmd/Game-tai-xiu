const express = require("express");
const app = express();
const http = require("http").createServer(app);
const io = require("socket.io")(http);

app.use(express.static("public"));

io.on("connection", socket => {
  console.log("User connected");

  socket.on("bet", type => {
    const dice = [
      rand(), rand(), rand()
    ];
    const total = dice.reduce((a, b) => a + b, 0);
    const result = total >= 11 ? "TÀI" : "XỈU";

    socket.emit("result", {
      dice,
      total,
      result,
      win: (type === "tai" && result === "TÀI") ||
           (type === "xiu" && result === "XỈU")
    });
  });
});

function rand() {
  return Math.floor(Math.random() * 6) + 1;
}

http.listen(3000, () => {
  console.log("Server running on port 3000");
});