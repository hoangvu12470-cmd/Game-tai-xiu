let getluong = require('./Controller/get.js');
let admin = require('./Controller/admin.js');
module.exports = {
	message:    getluong,
	admin : admin,
};
