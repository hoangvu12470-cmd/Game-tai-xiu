let game = 
{ 
	id : -1,
	t  : 0,
	x  : 0,
	at : 0,
	ax : 0,
	b  : 0,
	a  : 0,
	bc1 : 0,
	bc2 : 0,
	bc3 : 0,
	bc4 : 0,
	bc5 : 0,
	bc6 : 0,
	trangthai : '',
	x1 : 0,
	x2 : 0,
	x3 : 0,
	b1 : 0,
	b2 : 0,
	b3 : 0,
    cuoc : [],
};

module.exports = game;