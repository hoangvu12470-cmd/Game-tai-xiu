let config = {};

module.exports = config;